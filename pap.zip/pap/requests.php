<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Contact | VP Gaming</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/prettyPhoto.css" rel="stylesheet">
    <link href="css/price-range.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
	<link href="css/main.css" rel="stylesheet">
	<link href="css/responsive.css" rel="stylesheet">
        
    <link rel="shortcut icon" href="images/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57-precomposed.png">
</head>
<body>
	<header id="header">
		<div class="header_top">
			<div class="container">
				<div class="row">
					<div class="col-sm-6">
						<div class="contactinfo">
							<ul class="nav nav-pills">
								<li><a href=""><i class="fa fa-phone"></i> +2 95 01 88 821</a></li>
								<li><a href=""><i class="fa fa-envelope"></i> vpgaming@gmail.com</a></li>
							</ul>
						</div>
					</div>
					<div class="col-sm-6">
						<div class="social-icons pull-right">
							<ul class="nav navbar-nav">
								<li><a href="https://www.facebook.com/vp.gaming.980" target="_blank"><i class="fa fa-facebook"></i></a></li>
								<li><a href="https://twitter.com/VPGaming16" target="_blank"><i class="fa fa-twitter"></i></a></li>
								<li><a href="https://www.instagram.com/__vpgaming__/" target="_blank"><i class="fa fa-instagram"></i></a></li>
							
								
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div><!--/header_top-->
		
		<div class="header-middle"><!--header-middle-->
			<div class="container">
				<div class="row">
					<div class="col-md-4 clearfix">
						<div class="logo pull-left">
							<a href="index.php"><img src="images/home/logo.png" alt="" /></a>
						</div>
						<div class="btn-group pull-right clearfix">
							
						</div>
					</div>
					<div class="col-md-8 clearfix">
						<div class="shop-menu clearfix pull-right">
							<ul class="nav navbar-nav">
								<li><a href=""><i class="fa fa-user"></i> Account</a></li>
								
							
								
								<li><a href="login.php"><i class="fa fa-lock"></i> Login</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div><!--/header-middle-->
	
		<div class="header-bottom"><!--header-bottom-->
			<div class="container">
				<div class="row">
					<div class="col-sm-9">
						<div class="mainmenu pull-left">
							<ul class="nav navbar-nav collapse navbar-collapse">
								<li><a href="index.php">Home</a></li>
								<li class="dropdown"><a href="#">Shop<i class="fa fa-angle-down"></i></a>
                                    <ul role="menu" class="sub-menu">
                                        <li><a href="shop.html">Products</a></li>
										
										<li><a href="login.php">Login</a></li> 
                                    </ul>
                                </li> 
								
								
								<li><a href="requests.php" class="active">Requests</a></li><li><a href="aboutus.php">About Us</a></li>
							</ul>
						</div>
					</div>
					<div class="col-sm-3">
						<div class="search_box pull-right">
							<!--<input type="text" placeholder="Search"/>-->
						</div>
					</div>
				</div>
			</div>
		</div><!--/header-bottom-->
	</header><!--/header-->

<?php

if($_SERVER['REQUEST_METHOD']=='POST'){
	$nome="";
	$email="";
	$jogo="";
	$mensagem="";
	$preco=0;
	$data_compra="";
	$chave="";

	if(isset($_POST['nome'])){
		$nome=$_POST['nome'];
	}
	else{
		echo '<script>alert("É obrigatorio o preenchimento do nome.");</script>';
		}
	if(isset($_POST['email'])){
		$email = $_POST['email'];
		}
	if(isset($_POST['jogo'])){
		$jogo = $_POST['jogo'];
		}
	if(isset($_POST['mensagem'])){
		$mensagem = $_POST['mensagem'];
		}
	if(isset($_POST['preco']) && is_numeric($_POST['preco'])){
		$preco= $_POST['preco'];
		}
	if(isset($_POST['data_compra'])){
		$data_compra = $_POST['data_compra'];
		}
	if(isset($_POST['chave'])){
		$chave = $_POST['chave'];

}
$con=new mysqli("localhost","root","","papjogos");

if($con->connect_errno!=0){
	echo "Ocorreu um erro no acesso à base de dados.<br>".$con->connect_error;
	exit;

	}
else{
	
	$sql='insert into mensagem(nome,email,jogo,mensagem,preco,data_compra,chave)values(?,?,?,?,?,?,?)';
		$stm=$con->prepare( $sql);
		if($stm!=false){

			$stm->bind_param('ssssiss',$nome,$email,$jogo,$mensagem,$preco,$data_compra,$chave);
			$stm->execute();
			$stm->close();

			echo '<script>alert ("Compra feita com sucesso");</script>';

			echo 'Aguarde um momento.A reencaminhar página';
			header("refresh:5;url=index.php");
		}
		else{
			echo ($con->error);
			echo "Aguarde um momento.A reencaminhar página";
			header("refresh:5;url=index.php");
		}
		}//end if-if($con->connect_errno!=0)
}//if($_SERVER´['REQUEST_METHOD']=="POST")
else{ //else if($_SERVER['REQUEST_METHOD']=="POST")
  ?>

  	<!DOCTYPE html>
  	<html>
  	<head>
  		<meta charset="ISO_8859-1">
  		<title>Request Game</title>
  	</head>
  	<body>
  	<h2 class="title text-center">Get Your Game</h2>
	<div align="center" >
  	<form action="requests.php" method="post">
  	<center><label>Nome&nbsp;</label><input type="text" name="nome" class="" required="required" placeholder="Your Name">
  	<br>
  	<br>
  	<label>Email&nbsp;</label><input type="text" name="email" class="" required="required" placeholder="Your Email">
  	<br>
  	<br>
  	<label>Jogo&nbsp;</label><input type="text" name="jogo" class="" required="required" placeholder="Game">
  	<br>
  	<br>
  	<label>Mensagem&nbsp;</label><input type="text" name="mensagem" class="" required="required" placeholder="Message">
  	<br>
  	<br>
  	<label>Preco&nbsp;</label><input type="text" name="preco" class="" required="required" placeholder="Price">
  	<br>
  	<br>
  	<label>Data_Compra&nbsp;</label><input type="date" name="data_compra" class="" required="required" placeholder="Buy date">
  	<br>
  	<br>
  	<label>Chave&nbsp;</label><input type="text" name="chave" class="" required="required" placeholder="key">
  	<br>
  	<br>
    <button align="center" type="submit" name="submit" class="btn btn-primary pull-center" value="Submit">Submit</button>  
  	</form>
  	</div>
  	</body>
  	</html>



<?php
 }//end if-if($_SERVER['REQUEST_METHOD']=="POST")
?>

<br>
<br>
<br>

	    			<div class="contact-info">
	    				<h2 class="title text-center">Contact Info</h2>
	    				<address>
	    					<center><p>VP Gaming Inc.</p></center>
							<center><p>Rua de Santa Catarina 801, 4000-454 Porto</p></center>
							<center><p>Porto, Portugal</p></center>
							<center><p>Mobile: 910577960 </p></center>
							<center><p>Email: vpgaming@gmail.com</p></center>
	    				</address>
	    				<div class="social-networks">
	    					<h2 class="title text-center">Social Networking</h2>
							<ul>
								<li>
									<a href="https://www.facebook.com/vp.gaming.980" target="_blank"><i class="fa fa-facebook"></i></a>
								</li>
								<li>
									<a href="https://twitter.com/VPGaming16" target="_blank"><i class="fa fa-twitter"></i></a>
								</li>
								<li>
									<a href="https://www.instagram.com/__vpgaming__/" target="_blank"><i class="fa fa-instagram"></i></a></li>
								</li>
							</ul>
	    				</div>
	    			</div>
    			</div>    			
	    	</div>  
    	</div>	
    </div>  <!--/#contact-page--> 

	<hr>


<div align="left" class="col-lg-4 col-md-12">
<div class="delivery methods block one"><img src="https://static.pcdiga.com/media/icons/ic-ecommerce-delivery_2x.png" alt="">
<p class="delivery methods title">Entregas em 24 horas</p>
<p>Tempo médio em dias úteis para Portugal Continental</p>
</div>
</div>
<div align="center" class="col-lg-4 col-md-12">
<div class="delivery methods block two"><img src="https://static.pcdiga.com/media/icons/ic-ecommerce-house_2x.png" alt="">
<p class="delivery methods title">Levante na Loja</p>
<p>Compre online e levante a sua encomenda na loja VPGaming</p>
</div>
</div>
<div align="right" class="col-lg-4 col-md-12">
<div class="delivery methods block three"><img src="https://static.pcdiga.com/media/icons/Group_16045_2x.png" alt="">
<p  class="delivery methods title">Portes Grátis</p>
<p>Em compras superiores a 200€ para Portugal Continental</p>
</div>
</div>
</div>
	
			

  
    <script src="js/jquery.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/contact.js"></script>
	<script src="js/price-range.js"></script>
    <script src="js/jquery.scrollUp.min.js"></script>
    <script src="js/jquery.prettyPhoto.js"></script>
    <script src="js/main.js"></script>
</body>
</html>
	