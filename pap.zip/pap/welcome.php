<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body{ font: 14px sans-serif; text-align: center; }
    </style>
</head>
<body>
    <h1 class="my-5">Hi, <b><?php echo htmlspecialchars($_SESSION["username"]); ?></b>. Welcome to our site.</h1>
    <p>
        
        <a href="logout.php" class="btn btn-danger ml-3">Sign Out of Your Account</a>
    </p>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Home | VP Gaming</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/prettyPhoto.css" rel="stylesheet">
    <link href="css/price-range.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/main.css" rel="stylesheet">
    <link href="css/responsive.css" rel="stylesheet">
  


    <link rel="shortcut icon" href="images/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57-precomposed.png">
</head><!--/head-->


        
        <div class="header-middle"><!--header-middle-->
            <div class="container">
                <div class="row">
                    <div class="col-md-4 clearfix">
                        <div class="logo pull-left">
                            <a href="index.php"><img align="center" src="images/home/logo.PNG" alt="" /></a>
                        </div>
                        <div class="btn-group pull-right clearfix">
                            
                        </div>
                    </div>
                    
    
        <div class="header-bottom"><!--header-bottom-->
            <div class="container">
                <div class="row">
                    <div class="col-sm-9">
                        <div class="navbar-header">
                            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                        </div>
                        <div class="mainmenu pull-left">
                            <ul class="nav navbar-nav collapse navbar-collapse">
                                <li><a href="index.php" class="">Home</a></li>
                                <li class="dropdown"><a href="#">Shop<i class="fa fa-angle-down"></i></a>
                                    <ul role="menu" class="sub-menu">
                                        <li><a href="shop.html">Products</a></li>
                                         
                                       
                                        <li><a href="login.php">Login</a></li> 
                                    </ul>
                               
                                <li><a href="requests.php">Requests</a></li> <li><a href="aboutus.php">About Us</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="search_box pull-right">
                            <!--<input type="text" placeholder="Search"/>-->
                        </div>
                    </div>
                </div>
            </div>
        </div><!--/header-bottom-->
    </header><!--/header-->
    
    <section id="slider"><!--slider-->
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <div id="slider-carousel" class="carousel slide" data-ride="carousel">
                        <ol class="carousel-indicators">
                            <li data-target="#slider-carousel" data-slide-to="0" class="active"></li>
                            <li data-target="#slider-carousel" data-slide-to="1"></li>
                            <li data-target="#slider-carousel" data-slide-to="2"></li>
                        </ol>
                        
                        <div class="carousel-inner">
                            <div class="item active">
                                <div class="col-sm-6">
                                    <h1><span>VP</span>-Gaming</h1>
                                    <h2>DESPORTO</h2>
                                    <p>eFootball Pro Evolution Soccer 2021 , é um jogo eletrônico de futebol desenvolvido pela PES Production e publicado pela Konami.</p>
                                    <br><br>
                                </div>
                                <div class="col-sm-6">
                                    <img width="1000px" height="1000px" src="images/home/pes21.jpg" class="girl img-responsive" alt="" />
                                    
                                </div>
                            </div>
                            <div class="item">
                                <div class="col-sm-6">
                                    <h1><span>VP</span>-Gaming</h1>
                                    <h2>GUERRA</h2>
                                    <p>Valorant é um jogo eletrônico multijogador gratuito para jogar de tiro em primeira pessoa desenvolvido e publicado pela Riot Games. </p>
                                <br><br>
                                </div>
                                <div class="col-sm-6">
                                    <img width="1000px" height="1000px" src="images/home/valorant.jpg" class="girl img-responsive" alt="" />
                                    
                                </div>
                            </div>
                            
                            <div class="item">
                                <div class="col-sm-6">
                                    <h1><span>VP</span>-Gaming</h1>
                                    <h2>DESPORTO</h2>
                                    <p>FIFA 21 é um videogame de simulação de esportes desenvolvido pela Electronic Arts e publicado pela mesma empresa. </p>
                                    <br><br>
                                </div>
                                <div class="col-sm-6">
                                    <img width="1000px" height="1000px" src="images/home/fifa21.jpg" class="girl img-responsive" alt="" />
                                    
                                </div>
                            </div>
                            
                        </div>
                        
                        <a href="#slider-carousel" class="left control-carousel hidden-xs" data-slide="prev">
                            <i class="fa fa-angle-left"></i>
                        </a>
                        <a href="#slider-carousel" class="right control-carousel hidden-xs" data-slide="next">
                            <i class="fa fa-angle-right"></i>
                        </a>
                    </div>
                    
                </div>
            </div>
        </div>
    </section><!--/slider-->
    
   
                
                    
                    <div class="category-tab">
                        <div class="col-sm-12">
                            
                                <h2 align="center"> Popular</h2>

                                
                            </ul>
                        </div>
                        <div class="tab-content">
                            <div class="tab-pane fade active in" id="popular" >
                                <div class="col-sm-3">
                                    <div class="product-image-wrapper">
                                        <div class="single-products">
                                            <div class="productinfo text-center">
                                                <img src="images/home/fifa21.jpg" alt="" width="200" height="140" />
                                                <h2>$50</h2>
                                                <p>FIFA 21</p>
                                                <a href="requests.php" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>BUY</a>
                                            </div>
                                            
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="product-image-wrapper">
                                        <div class="single-products">
                                            <div class="productinfo text-center">
                                                <img src="images/home/minecraft.jpg" alt="" width="200" height="140" />
                                                <h2>$20</h2>
                                                <p>MINECRAFT</p>
                                                <a href="requests.php" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>BUY</a>
                                            </div>
                                            <img src="images/home/sale.png" class="new" alt=""  height="70px" />
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="product-image-wrapper">
                                        <div class="single-products">
                                            <div class="productinfo text-center">
                                                <img src="images/home/gtaV.jpg" alt="" width="200" height="140" />
                                                <h2>$60</h2>
                                                <p>GTA V</p>
                                                <a href="requests.php" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>BUY</a>
                                            </div>
                                            
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="product-image-wrapper">
                                        <div class="single-products">
                                            <div class="productinfo text-center">
                                                <img src="images/home/motogp.jpg" alt="" width="200" height="140" />
                                                <h2>$65</h2>
                                                <p>MOTOGP 21</p>
                                                <a href="requests.php" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>BUY</a>
                                            </div>
                                            
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="product-image-wrapper">
                                        <div class="single-products">
                                            <div class="productinfo text-center">
                                                <img src="images/home/supermarioparty.jpg" alt="" width="200" height="140" />
                                                <h2>$10</h2>
                                                <p>SUPER MARIO PARTY</p>
                                                <a href="requests.php" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>BUY</a>
                                            </div>
                                            <img src="images/home/new.png" class="new" alt=""  height="70px" />
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="product-image-wrapper">
                                        <div class="single-products">
                                            <div class="productinfo text-center">
                                                <img src="images/home/pes21.jpg" alt="" width="200" height="140" />
                                                <h2>$40</h2>
                                                <p>PES 21</p>
                                                <a href="requests.php" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>BUY</a>
                                            </div>
                                            
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="product-image-wrapper">
                                        <div class="single-products">
                                            <div class="productinfo text-center">
                                                <img src="images/home/valorant.jpg" alt="" width="200" height="140" />
                                                <h2>FREE</h2>
                                                <p>VALORANT</p>
                                                <a href="requests.php" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>BUY</a>
                                            </div>
                                            
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="product-image-wrapper">
                                        <div class="single-products">
                                            <div class="productinfo text-center">
                                                <img src="images/home/lol.jpg" alt="" width="200" height="140" />
                                                <h2>$10</h2>
                                                <p>LEAGUE OF LEGENDS</p>
                                                <a href="requests.php" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>BUY</a>
                                            </div>
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                            

                </div>
            </div>
        </div>
    </section>
    
    
        <hr>

<div align="left" class="col-lg-4 col-md-12">
<div class="delivery methods block one"><img src="https://static.pcdiga.com/media/icons/ic-ecommerce-delivery_2x.png" alt="">
<p class="delivery methods title">Entregas em 24 horas</p>
<p>Tempo médio em dias úteis para Portugal Continental</p>
</div>
</div>
<div align="center" class="col-lg-4 col-md-12">
<div class="delivery methods block two"><img src="https://static.pcdiga.com/media/icons/ic-ecommerce-house_2x.png" alt="">
<p class="delivery methods title">Levante na Loja</p>
<p>Compre online e levante a sua encomenda na loja VPGaming</p>
</div>
</div>
<div align="right" class="col-lg-4 col-md-12">
<div class="delivery methods block three"><img src="https://static.pcdiga.com/media/icons/Group_16045_2x.png" alt="">
<p  class="delivery methods title">Portes Grátis</p>
<p>Em compras superiores a 200€ para Portugal Continental</p>
</div>
</div>
</div>

    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.scrollUp.min.js"></script>
    <script src="js/price-range.js"></script>
    <script src="js/jquery.prettyPhoto.js"></script>
    <script src="js/main.js"></script>
</body>
</html>
</body>
</html>